# 快速启动指南 - v1.6.1.2

## 🚀 一分钟快速开始

### Windows 用户

1. **启动服务器**
   ```
   双击运行: start_server.bat
   ```

2. **访问系统**
   ```
   浏览器打开: http://127.0.0.1:8000/
   ```

3. **登录**
   ```
   用户名: superuser01
   密码: 123456
   ```

### Linux/Mac 用户

1. **启动服务器**
   ```bash
   bash start_server.sh
   ```

2. **访问系统**
   ```
   浏览器打开: http://127.0.0.1:8000/
   ```

3. **登录**
   ```
   用户名: superuser01
   密码: 123456
   ```

## 📋 可用测试账号

| 用户名 | 密码 | 角色 |
|--------|------|------|
| superuser01 | 123456 | 超级管理员 |
| branch_manager01 | 123456 | 任务区负责人 |
| test_employee | 123456 | 普通员工 |
| test_manager | 123456 | 任务区负责人 |

## 🔧 工具使用

### 检查用户信息
```bash
python check_users_db.py
```

### 测试登录功能
```bash
python test_login_all_users.py
```

### 重置所有密码
```bash
python fix_user_passwords.py
```

## ⚠️ 常见问题

### 问题1: 无法启动服务器
**解决方案**:
```bash
pip install Django==4.2.7 Pillow pytz
```

### 问题2: 端口被占用
**解决方案**:
修改端口号:
```bash
python manage.py runserver 8001
```

### 问题3: 无法登录
**解决方案**:
运行密码修复工具:
```bash
python fix_user_passwords.py
```

### 问题4: 忘记密码
**解决方案**:
运行密码修复工具将所有密码重置为 123456:
```bash
python fix_user_passwords.py
```

## 📚 更多信息

- 完整文档: [README.md](README.md)
- 修复说明: [LOGIN_FIX_README_v1.6.1.2.md](LOGIN_FIX_README_v1.6.1.2.md)
- 版本信息: [VERSION_v1.6.1.2.md](VERSION_v1.6.1.2.md)

## 💡 提示

- 首次登录后建议修改密码
- 生产环境请务必更改默认密码
- 定期备份 db.sqlite3 数据库文件

---

**版本**: v1.6.1.2  
**发布日期**: 2025-11-02
