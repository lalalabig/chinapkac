from django.apps import AppConfig

class LocationTrackingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'location_tracking'
    verbose_name = '位置追踪'
