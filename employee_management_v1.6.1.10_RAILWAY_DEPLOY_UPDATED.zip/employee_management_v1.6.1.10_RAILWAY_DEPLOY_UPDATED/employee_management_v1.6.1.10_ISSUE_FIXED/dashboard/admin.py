from django.contrib import admin

# dashboard 应用不需要特定的 admin 配置
