"""
dashboard 应用模型
"""
from django.db import models

# 仪表盘主要显示数据，不需要特定模型
